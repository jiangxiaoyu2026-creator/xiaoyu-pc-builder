import os
from sqlmodel import SQLModel, create_engine, Session, select
from dotenv import load_dotenv

load_dotenv()

# Get absolute path for the DB file
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SQLITE_DB_PATH = os.getenv("SQLITE_DB_PATH", "data/xiaoyu.db")

if not os.path.isabs(SQLITE_DB_PATH):
    FULL_DB_PATH = os.path.join(BASE_DIR, SQLITE_DB_PATH)
else:
    FULL_DB_PATH = SQLITE_DB_PATH

# Ensure data directory exists
data_dir = os.path.dirname(FULL_DB_PATH)
if not os.path.exists(data_dir):
    os.makedirs(data_dir, exist_ok=True)

DATABASE_URL = f"sqlite:///{FULL_DB_PATH}"

engine = create_engine(DATABASE_URL, echo=False, connect_args={"check_same_thread": False})

from sqlalchemy import event

@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
#    cursor.execute("PRAGMA journal_mode=WAL")
#    cursor.execute("PRAGMA synchronous=NORMAL")
#    cursor.execute("PRAGMA cache_size=-64000") # 64MB cache max
    cursor.close()

def init_db():
    # 先运行 SQLModel 的基础创建
    SQLModel.metadata.create_all(engine)
    
    # 自动补全缺失的列 (由于 SQLModel 不支持自动 Add Column)
    _migrate_extra_columns()
    
    _create_default_admin()

def _migrate_extra_columns():
    """手动检查并补齐模型中定义但数据库中可能缺失的列"""
    import sqlite3
    try:
        conn = sqlite3.connect(FULL_DB_PATH)
        cursor = conn.cursor()
        
        # 补齐 users 表
        cursor.execute("PRAGMA table_info(users)")
        user_cols = [row[1] for row in cursor.fetchall()]
        if 'mobile' not in user_cols:
            cursor.execute("ALTER TABLE users ADD COLUMN mobile TEXT")
        if 'email' not in user_cols:
            cursor.execute("ALTER TABLE users ADD COLUMN email TEXT")
        if 'streamerExpireAt' not in user_cols:
            cursor.execute("ALTER TABLE users ADD COLUMN streamerExpireAt INTEGER")
            
        # 补齐 configs 表
        cursor.execute("PRAGMA table_info(configs)")
        config_cols = [row[1] for row in cursor.fetchall()]
        if 'title' not in config_cols:
            cursor.execute("ALTER TABLE configs ADD COLUMN title TEXT")
        if 'description' not in config_cols:
            cursor.execute("ALTER TABLE configs ADD COLUMN description TEXT")
        if 'showcaseImages' not in config_cols:
            cursor.execute("ALTER TABLE configs ADD COLUMN showcaseImages TEXT NOT NULL DEFAULT '[]'")
        if 'showcaseMessage' not in config_cols:
            cursor.execute("ALTER TABLE configs ADD COLUMN showcaseMessage TEXT")
        if 'showcaseStatus' not in config_cols:
            cursor.execute("ALTER TABLE configs ADD COLUMN showcaseStatus TEXT NOT NULL DEFAULT 'none'")
            
        # 补齐 hardware 表
        cursor.execute("PRAGMA table_info(hardware)")
        hw_cols = [row[1] for row in cursor.fetchall()]
        if 'imageSource' not in hw_cols:
            cursor.execute("ALTER TABLE hardware ADD COLUMN imageSource TEXT NOT NULL DEFAULT 'user'")
        if 'specsSource' not in hw_cols:
            cursor.execute("ALTER TABLE hardware ADD COLUMN specsSource TEXT NOT NULL DEFAULT 'user'")
        if 'costPrice' not in hw_cols:
            cursor.execute("ALTER TABLE hardware ADD COLUMN costPrice REAL NOT NULL DEFAULT 0.0")
        if 'profitType' not in hw_cols:
            cursor.execute("ALTER TABLE hardware ADD COLUMN profitType TEXT NOT NULL DEFAULT 'fixed'")
        if 'profitValue' not in hw_cols:
            cursor.execute("ALTER TABLE hardware ADD COLUMN profitValue REAL NOT NULL DEFAULT 0.0")
            
        # Add Indexes for performance optimization
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_configs_userId ON configs(userId)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_configs_status ON configs(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_used_sellerId ON used_items(sellerId)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_used_category ON used_items(category)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_used_status ON used_items(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_hardware_category ON hardware(category)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_hardware_status ON hardware(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_userId ON orders(userId)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)")
            
        # Deduplicate recycling prices keeping the most recently added for each category+model pair
        cursor.execute("""
            DELETE FROM recycling_prices
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM recycling_prices
                GROUP BY category, model
            )
        """)
        
        # Add index for recycling prices to prevent future lookup collisions and speed it up
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_recycling_prices_cat_model ON recycling_prices(category, model)")

        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Migration error: {e}")

def _create_default_admin():
    """创建默认管理员账户"""
    from .models import User
    from .utils.auth import get_password_hash

    with Session(engine) as session:
        # 检查是否已存在管理员
        existing = session.exec(select(User).where(User.username == "xiaoyu")).first()
        if existing:
            return

        # 创建默认管理员
        admin = User(
            id="admin-default-001",
            username="xiaoyu",
            password=get_password_hash("jiangxiaoyu119"),
            role="admin",
            status="active"
        )
        session.add(admin)
        session.commit()
        print("Default admin created: xiaoyu / jiangxiaoyu119")

def get_session():
    with Session(engine) as session:
        yield session
